from __future__ import annotations

import argparse
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp/lab_matplotlib_cache")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


DEFAULT_CSV_PATHS = [
    Path(
        "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/"
        "visual_trend_setup/combined_lab_collection_summary_setup.csv"
    ),
    Path(
        "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/"
        "visual_trend_act1/combined_lab_collection_summary_act1.csv"
    ),
    Path(
        "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/"
        "visual_trend_act2/combined_lab_collection_summary_act2.csv"
    ),
    Path(
        "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/"
        "visual_trend_act3/combined_lab_collection_summary_act3.csv"
    ),
]
DEFAULT_LABELS = ["setup", "act1", "act2", "act3"]
DEFAULT_OUTPUT_DIR = Path(
    "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/water_clip_deviation"
)
DEFAULT_FOCUS_CLIPS = {
    "clip1": "setup",
    "clip2": "setup",
    "clip3": "act1",
    "clip4": "act1",
    "clip5": "act1",
    "clip6": "act1",
    "clip7": "act2",
    "clip8": "act2",
    "clip9": "act2",
    "clip10": "act3",
    "clip11": "act3",
    "clip12": "act3",
}

METRICS = [
    ("average_L_across_images", "L*", "#FFC000"),
    ("average_chroma_across_images", "Mean chroma", "blue"),
    ("average_chroma_std_across_images", "Chroma std", "purple"),
    ("average_chroma_p95_across_images", "Chroma p95", "red"),
    ("average_high_chroma_pixel_pct_across_images", "High-chroma pixels %", "green"),
    ("average_contrast_across_images", "Contrast", "#FFC000"),
]


def normalize_clip_name(value: str) -> str:
    value = value.strip().lower()
    if value.startswith("clip"):
        return value
    if value.isdigit():
        return f"clip{value}"
    return value


def parse_labels(label_text: str | None, csv_paths: list[Path]) -> list[str]:
    if label_text is None:
        if len(csv_paths) == len(DEFAULT_LABELS):
            return DEFAULT_LABELS.copy()
        return [path.parent.name for path in csv_paths]

    labels = [label.strip() for label in label_text.split(",") if label.strip()]
    if len(labels) != len(csv_paths):
        raise SystemExit(
            f"--labels must provide exactly {len(csv_paths)} labels, separated by commas."
        )
    return labels


def parse_focus_clips(focus_text: str | None) -> dict[str, str]:
    if focus_text is None:
        return DEFAULT_FOCUS_CLIPS.copy()

    focus: dict[str, str] = {}
    for item in focus_text.split(","):
        item = item.strip()
        if not item:
            continue
        if ":" not in item:
            raise SystemExit(
                "Each --focus-clips item must look like clip1:setup or 1:setup."
            )
        clip, set_label = [part.strip() for part in item.split(":", 1)]
        focus[normalize_clip_name(clip)] = set_label

    if not focus:
        raise SystemExit("No focus clips were provided.")
    return focus


def numeric_value(row: pd.Series, column: str) -> float | None:
    if column not in row.index:
        return None
    value = pd.to_numeric(pd.Series([row[column]]), errors="coerce").iloc[0]
    if pd.isna(value):
        return None
    return float(value)


def load_set_tables(csv_paths: list[Path], labels: list[str]) -> dict[str, pd.DataFrame]:
    tables: dict[str, pd.DataFrame] = {}
    missing_paths = [path for path in csv_paths if not path.exists()]
    if missing_paths:
        missing_text = "\n".join(str(path) for path in missing_paths)
        raise SystemExit(f"CSV path(s) not found:\n{missing_text}")

    for path, label in zip(csv_paths, labels, strict=True):
        df = pd.read_csv(path)
        if "clip" not in df.columns:
            raise SystemExit(f"CSV lacks required 'clip' column: {path}")
        df = df.copy()
        df["clip"] = df["clip"].astype(str).map(normalize_clip_name)
        tables[label] = df

    return tables


def set_average_row(df: pd.DataFrame, label: str) -> pd.Series:
    average_rows = df[df["clip"] == "all clips"]
    if average_rows.empty:
        raise SystemExit(f"No 'all clips' average row found for set: {label}")
    return average_rows.iloc[-1]


def build_set_average_df(tables: dict[str, pd.DataFrame], labels: list[str]) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for index, label in enumerate(labels, start=1):
        average_row = set_average_row(tables[label], label)
        row: dict[str, object] = {
            "set": label,
            "set_order": index,
            "image_count": int(pd.to_numeric(average_row.get("image_count", 0), errors="coerce")),
        }
        for metric, _, _ in METRICS:
            value = numeric_value(average_row, metric)
            if value is not None:
                row[metric] = value
        rows.append(row)
    return pd.DataFrame(rows)


def fit_trend(set_averages: pd.DataFrame, metric: str) -> tuple[float, float] | None:
    values = pd.to_numeric(set_averages.get(metric), errors="coerce")
    x = pd.to_numeric(set_averages["set_order"], errors="coerce")
    valid = values.notna() & x.notna()
    if valid.sum() < 2:
        return None
    slope, intercept = np.polyfit(x[valid], values[valid], deg=1)
    return float(slope), float(intercept)


def percent_delta(value: float, baseline: float) -> float | None:
    if baseline == 0:
        return None
    return (value - baseline) / abs(baseline) * 100.0


def relation_label(delta: float, tolerance: float) -> str:
    if abs(delta) <= tolerance:
        return "aligned"
    if delta > 0:
        return "above"
    return "below"


def build_deviation_table(
    tables: dict[str, pd.DataFrame],
    labels: list[str],
    focus_clips: dict[str, str],
    tolerance_pct: float,
) -> pd.DataFrame:
    set_averages = build_set_average_df(tables, labels)
    set_order = {label: index for index, label in enumerate(labels, start=1)}
    global_averages = {
        metric: float(np.average(
            pd.to_numeric(set_averages[metric], errors="coerce"),
            weights=pd.to_numeric(set_averages["image_count"], errors="coerce"),
        ))
        for metric, _, _ in METRICS
        if metric in set_averages.columns
    }
    trend_fits = {
        metric: fit_trend(set_averages, metric)
        for metric, _, _ in METRICS
        if metric in set_averages.columns
    }

    rows: list[dict[str, object]] = []
    for clip, expected_set in focus_clips.items():
        if expected_set not in tables:
            print(f"Warning: set {expected_set!r} not found for {clip}; skipping.")
            continue

        clip_rows = tables[expected_set][tables[expected_set]["clip"] == clip]
        if clip_rows.empty:
            print(f"Warning: {clip} not found in set {expected_set}; skipping.")
            continue

        clip_row = clip_rows.iloc[-1]
        average_row = set_average_row(tables[expected_set], expected_set)

        for metric, metric_label, _ in METRICS:
            clip_value = numeric_value(clip_row, metric)
            set_average = numeric_value(average_row, metric)
            if clip_value is None or set_average is None:
                continue

            set_delta = clip_value - set_average
            set_delta_pct = percent_delta(clip_value, set_average)
            global_average = global_averages.get(metric)
            global_delta = None if global_average is None else clip_value - global_average
            global_delta_pct = (
                None if global_average is None else percent_delta(clip_value, global_average)
            )

            trend_value = None
            trend_delta = None
            trend_delta_pct = None
            trend_slope = None
            trend_relation = ""
            trend_fit = trend_fits.get(metric)
            if trend_fit is not None:
                trend_slope, trend_intercept = trend_fit
                trend_value = trend_slope * set_order[expected_set] + trend_intercept
                trend_delta = clip_value - trend_value
                trend_delta_pct = percent_delta(clip_value, trend_value)
                trend_relation = relation_label(
                    trend_delta,
                    max(abs(trend_value) * tolerance_pct / 100.0, 1e-9),
                )

            rows.append(
                {
                    "clip": clip,
                    "expected_set": expected_set,
                    "set_order": set_order[expected_set],
                    "metric": metric,
                    "metric_label": metric_label,
                    "clip_value": clip_value,
                    "set_average": set_average,
                    "deviation_from_set_average": set_delta,
                    "deviation_from_set_average_pct": set_delta_pct,
                    "set_relation": relation_label(
                        set_delta,
                        max(abs(set_average) * tolerance_pct / 100.0, 1e-9),
                    ),
                    "all_sets_average": global_average,
                    "deviation_from_all_sets_average": global_delta,
                    "deviation_from_all_sets_average_pct": global_delta_pct,
                    "trend_expected_value": trend_value,
                    "deviation_from_trend": trend_delta,
                    "deviation_from_trend_pct": trend_delta_pct,
                    "trend_relation": trend_relation,
                    "trend_slope_per_set": trend_slope,
                }
            )

    if not rows:
        raise SystemExit("No focus clip rows were found.")
    return pd.DataFrame(rows)


def save_focus_plot(
    set_averages: pd.DataFrame,
    deviations: pd.DataFrame,
    output_dir: Path,
) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(18, 10), sharex=True)
    axes = axes.flatten()
    x_sets = set_averages["set_order"].to_numpy()
    set_labels = set_averages["set"].astype(str).tolist()

    for ax, (metric, metric_label, color) in zip(axes, METRICS):
        if metric not in set_averages.columns:
            ax.axis("off")
            continue

        set_values = pd.to_numeric(set_averages[metric], errors="coerce")
        ax.plot(
            x_sets,
            set_values,
            color=color,
            marker="o",
            linewidth=2.6,
            label="set average",
        )

        trend_fit = fit_trend(set_averages, metric)
        if trend_fit is not None:
            slope, intercept = trend_fit
            trend_values = slope * x_sets + intercept
            ax.plot(
                x_sets,
                trend_values,
                color="black",
                linestyle=":",
                linewidth=1.8,
                label="linear trend",
            )

        metric_deviations = deviations[deviations["metric"] == metric]
        for _, row in metric_deviations.iterrows():
            ax.scatter(
                row["set_order"],
                row["clip_value"],
                color=color,
                edgecolor="black",
                linewidth=0.8,
                s=48,
                zorder=3,
            )
            ax.annotate(
                row["clip"],
                (row["set_order"], row["clip_value"]),
                xytext=(4, 4),
                textcoords="offset points",
                fontsize=8,
            )

        ax.set_title(metric_label)
        ax.set_xticks(x_sets)
        ax.set_xticklabels(set_labels, rotation=25, ha="right")
        ax.grid(True, alpha=0.22)

    handles, labels = axes[0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="upper center", ncol=2)
    fig.suptitle("Water Clip Deviation From Set Averages and Set-Level Trend", y=0.995)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(output_dir / "focus_clip_deviation_trends.png", dpi=300)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Analyze how focus clips deviate from their set averages and the set-level LAB trend."
        )
    )
    parser.add_argument(
        "csv_paths",
        nargs="*",
        type=Path,
        help="Combined LAB summary CSVs, in narrative/development order.",
    )
    parser.add_argument(
        "--labels",
        type=str,
        default=None,
        help="Comma-separated set labels matching the CSV path order.",
    )
    parser.add_argument(
        "--focus-clips",
        type=str,
        default=None,
        help=(
            "Comma-separated focus clips and expected sets, e.g. "
            "clip1:setup,clip2:setup,clip3:act1."
        ),
    )
    parser.add_argument(
        "--tolerance-pct",
        type=float,
        default=5.0,
        help="Percent tolerance for calling a clip aligned with an average/trend.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Output folder. Default: {DEFAULT_OUTPUT_DIR}",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    csv_paths = [path.expanduser() for path in args.csv_paths] or DEFAULT_CSV_PATHS
    labels = parse_labels(args.labels, csv_paths)
    focus_clips = parse_focus_clips(args.focus_clips)

    output_dir = args.output_dir.expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    tables = load_set_tables(csv_paths, labels)
    set_averages = build_set_average_df(tables, labels)
    deviations = build_deviation_table(
        tables,
        labels,
        focus_clips,
        tolerance_pct=args.tolerance_pct,
    )

    set_averages.to_csv(output_dir / "set_average_values.csv", index=False)
    deviations.to_csv(output_dir / "focus_clip_deviation_summary.csv", index=False)
    save_focus_plot(set_averages, deviations, output_dir)

    print("Focus clip deviation analysis finished.")
    print(f"Analyzed {deviations['clip'].nunique()} focus clip(s).")
    print(f"Saved set averages to: {output_dir / 'set_average_values.csv'}")
    print(f"Saved deviation CSV to: {output_dir / 'focus_clip_deviation_summary.csv'}")
    print(f"Saved plot to: {output_dir / 'focus_clip_deviation_trends.png'}")


if __name__ == "__main__":
    main()

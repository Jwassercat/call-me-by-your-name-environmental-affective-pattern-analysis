from __future__ import annotations

import argparse
import os
import re
from pathlib import Path

import cv2
import numpy as np
import pandas as pd


DEFAULT_INPUT_DIR = Path("/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/clip24")
PLOT_COLORS = {
    "lightness": "#FFC000",
    "lightness_range": "#FFC000",
    "mean_chroma": "blue",
    "chroma_p95": "red",
    "high_chroma_pixels": "green",
}
EXCLUDED_IMAGE_DIRS = {
    ".matplotlib",
    "lab_analysis_output",
    "visual_trend_output",
    "visual_trend_plot_points",
}


def natural_key(path: Path) -> list[object]:
    return [
        float(part) if re.fullmatch(r"\d+(?:\.\d+)?", part) else part.lower()
        for part in re.split(r"(\d+(?:\.\d+)?)", str(path))
    ]


def find_png_images(input_dir: Path, output_dir: Path) -> list[Path]:
    output_dir = output_dir.resolve()
    image_paths: list[Path] = []

    for path in input_dir.rglob("*.png"):
        resolved_path = path.resolve()
        if resolved_path == output_dir or output_dir in resolved_path.parents:
            continue
        if EXCLUDED_IMAGE_DIRS.intersection(resolved_path.parts):
            continue
        image_paths.append(path)

    return sorted(image_paths, key=natural_key)


def tone_label(l_mean: float) -> str:
    if l_mean < 20:
        return "very dark"
    if l_mean < 35:
        return "dark"
    if l_mean < 55:
        return "dim, low-light"
    if l_mean < 75:
        return "moderately bright"
    return "bright"


def contrast_label(contrast: float) -> str:
    if contrast < 25:
        return "low lightness range"
    if contrast < 45:
        return "moderate lightness range"
    return "wide lightness range"


def saturation_label(chroma_mean: float, chroma_p95: float, high_chroma_pct: float) -> str:
    if chroma_mean < 8 and chroma_p95 < 20:
        return "globally desaturated"

    if chroma_mean < 16 and chroma_p95 >= 32:
        return "muted overall, but with vivid localized color areas"

    if chroma_mean < 16:
        return "muted overall color"

    if chroma_mean < 28 and chroma_p95 >= 40:
        return "moderate overall color with vivid highlights"

    if chroma_mean < 28:
        return "moderate color intensity"

    if high_chroma_pct >= 25:
        return "strong overall color intensity"

    return "strong color intensity in selected areas"


def color_cast_label(a_mean: float, b_mean: float) -> str:
    parts: list[str] = []

    if a_mean <= -8:
        parts.append("green/cyan cast")
    elif a_mean >= 8:
        parts.append("red/magenta cast")

    if b_mean <= -8:
        parts.append("blue/cool cast")
    elif b_mean >= 8:
        parts.append("yellow/warm cast")

    if not parts:
        return "near-neutral color cast"
    return " and ".join(parts)


def localized_vividness_label(chroma_p95: float, high_chroma_pct: float) -> str:
    if chroma_p95 >= 45 or high_chroma_pct >= 20:
        return "strong localized vividness"
    if chroma_p95 >= 32 or high_chroma_pct >= 10:
        return "noticeable localized vividness"
    return "limited localized vividness"


def visual_feeling(row: pd.Series | dict[str, float]) -> str:
    tone = tone_label(float(row["L"]))
    light_contrast = contrast_label(float(row["contrast"]))
    saturation = saturation_label(
        float(row["chroma"]),
        float(row["chroma_p95"]),
        float(row["high_chroma_pixel_pct"]),
    )
    vividness = localized_vividness_label(
        float(row["chroma_p95"]),
        float(row["high_chroma_pixel_pct"]),
    )
    cast = color_cast_label(float(row["a"]), float(row["b"]))

    return f"{tone}, {light_contrast}, {saturation}, {vividness}, {cast}"


def summarize_image(img_path: Path) -> dict[str, float | int | str] | None:
    img_bgr = cv2.imread(str(img_path), cv2.IMREAD_COLOR)
    if img_bgr is None:
        print(f"Could not read: {img_path}")
        return None

    img_lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
    l_raw, a_raw, b_raw = cv2.split(img_lab)

    L = l_raw * (100.0 / 255.0)
    a = a_raw - 128.0
    b = b_raw - 128.0
    chroma = np.hypot(a, b)

    height, width = img_bgr.shape[:2]
    pixel_count = int(width * height)

    return {
        "corpus_name": img_path.parent.name,
        "original_filename": img_path.name,
        "filename": img_path.name,
        "source_path": str(img_path),
        "width": int(width),
        "height": int(height),
        "pixel_count": pixel_count,

        "L": float(np.mean(L)),
        "a": float(np.mean(a)),
        "b": float(np.mean(b)),

        "chroma": float(np.mean(chroma)),
        "chroma_std": float(np.std(chroma)),
        "chroma_p95": float(np.percentile(chroma, 95)),
        "high_chroma_pixel_pct": float(np.mean(chroma > 28.0) * 100.0),

        "contrast": float(np.percentile(L, 95) - np.percentile(L, 5)),
    }


def add_collection_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["visual_feeling"] = df.apply(visual_feeling, axis=1)
    return df


def add_overall_average_row(df: pd.DataFrame) -> pd.DataFrame:
    average_row = {column: "" for column in df.columns}
    average_row["corpus_name"] = "overall average"

    numeric_columns = [
        "L", "a", "b", "chroma", "chroma_std",
        "chroma_p95", "high_chroma_pixel_pct", "contrast"
    ]

    for column in numeric_columns:
        average_row[column] = float(df[column].mean())

    average_row["visual_feeling"] = visual_feeling(average_row)

    return pd.concat([df, pd.DataFrame([average_row])], ignore_index=True)


def build_plots(df: pd.DataFrame, output_dir: Path) -> None:
    os.environ.setdefault("MPLCONFIGDIR", str(output_dir / ".matplotlib"))

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.arange(len(df))

    plt.figure(figsize=(12, 6))
    plt.plot(
        x,
        df["L"],
        marker="o",
        linewidth=2.5,
        color=PLOT_COLORS["lightness"],
        label="L: lightness",
    )
    plt.plot(x, df["a"], marker="o", label="a: green(-) red(+)")
    plt.plot(x, df["b"], marker="o", label="b: blue(-) yellow(+)")
    plt.xticks(x, df["original_filename"], rotation=90)
    plt.ylabel("CIE LAB value")
    plt.title("LAB Mean Values Across Images")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "lab_means_plot.png", dpi=300)
    plt.close()

    plt.figure(figsize=(12, 6))
    plt.plot(x, df["chroma"], marker="o", color=PLOT_COLORS["mean_chroma"], label="Mean chroma")
    plt.plot(
        x,
        df["chroma_p95"],
        marker="o",
        color=PLOT_COLORS["chroma_p95"],
        label="Chroma p95: localized vividness",
    )
    plt.plot(
        x,
        df["high_chroma_pixel_pct"],
        marker="o",
        color=PLOT_COLORS["high_chroma_pixels"],
        label="High-chroma pixels (%)",
    )
    plt.plot(
        x,
        df["contrast"],
        marker="o",
        color=PLOT_COLORS["lightness_range"],
        label="Lightness range: L* p95 - p05",
    )
    plt.xticks(x, df["original_filename"], rotation=90)
    plt.ylabel("Metric value")
    plt.title("Chroma, Localized Vividness, and Lightness Range")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "affective_metrics_plot.png", dpi=300)
    plt.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze PNG screenshots with CIE LAB metrics for film color and lighting."
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=DEFAULT_INPUT_DIR,
        help=f"Folder containing PNG images. Default: {DEFAULT_INPUT_DIR}",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output folder. Default: <input-dir>/lab_analysis_output",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_dir = args.input_dir.expanduser()
    output_dir = args.output_dir.expanduser() if args.output_dir else input_dir / "lab_analysis_output"
    output_dir.mkdir(parents=True, exist_ok=True)

    image_paths = find_png_images(input_dir, output_dir)
    if not image_paths:
        raise SystemExit(f"No PNG files found under: {input_dir}")

    rows = [row for path in image_paths if (row := summarize_image(path)) is not None]
    if not rows:
        raise SystemExit("No readable PNG files were found.")

    df = add_collection_columns(pd.DataFrame(rows))
    csv_df = add_overall_average_row(df)

    csv_path = output_dir / "lab_summary.csv"
    csv_df.to_csv(csv_path, index=False)

    build_plots(df, output_dir)

    print("LAB analysis finished.")
    print(f"Analyzed {len(df)} image(s).")
    print(f"Saved CSV to: {csv_path}")
    print(f"Saved LAB plot to: {output_dir / 'lab_means_plot.png'}")
    print(f"Saved affective metrics plot to: {output_dir / 'affective_metrics_plot.png'}")
    print()
    print("Overall visual feeling:")
    print(csv_df.iloc[-1]["visual_feeling"])


if __name__ == "__main__":
    main()

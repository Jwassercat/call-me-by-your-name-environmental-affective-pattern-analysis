import cv2
import os
import sys


def capture_screenshots(video_path, output_dir, interval=4.5, image_format='png'):
    """Capture screenshots from a local video at specified intervals."""
    # Validate video file
    if not os.path.exists(video_path):
        print(f"Error: Video file {video_path} does not exist.")
        return False

    # Open video
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Could not open video {video_path}.")
        return False

    # Get video properties
    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps <= 0:
        print(f"Warning: Invalid FPS for {video_path}. Using default FPS of 30.")
        fps = 30
    frame_interval = int(fps * interval)  # Frames to skip for each interval
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    video_name = os.path.splitext(os.path.basename(video_path))[0]

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    success = True
    frame_count = 0
    saved_count = 0

    while True:
        # Set position to next frame
        if frame_count > 0:
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_count)

        # Read frame
        ret, frame = cap.read()
        if not ret:
            break

        # Calculate timestamp
        timestamp = frame_count / fps

        # Save frame as image
        output_name = f"{video_name}_frame_{timestamp:.1f}.{image_format}"
        output_path = os.path.join(output_dir, output_name)
        try:
            cv2.imwrite(output_path, frame)
            print(f"Saved: {output_path}")
            saved_count += 1
        except Exception as e:
            print(f"Error saving {output_path}: {e}")
            success = False

        # Move to next interval
        frame_count += frame_interval

        # Break if we've exceeded total frames
        if frame_count >= total_frames:
            break

    cap.release()
    print(f"Processed {video_path}: {saved_count} screenshots saved.")
    return success

def main():
    # === Editable Paths ===
    # Video input directory containing the .mp4 files to process.
    video_dir = "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/clip24"

    # Screenshot output directory (edit this to where you want screenshots saved)
    output_dir = os.path.join(video_dir, "screenshots")

    # Default parameters
    interval = 4.5  # Seconds between screenshots
    image_format = "png"  # Output format: 'png' or 'jpg'

    # Optional: allow a custom input directory from the command line.
    if len(sys.argv) > 1:
        video_dir = sys.argv[1]
        output_dir = os.path.join(video_dir, "screenshots")

    if not os.path.isdir(video_dir):
        print(f"Error: Video directory {video_dir} does not exist.")
        sys.exit(1)

    video_extensions = (".mp4",)
    video_paths = [
        os.path.join(video_dir, filename)
        for filename in sorted(os.listdir(video_dir))
        if filename.lower().endswith(video_extensions)
    ]

    if not video_paths:
        print(f"No .mp4 files found in {video_dir}.")
        sys.exit(1)

    success_count = 0
    total_videos = len(video_paths)

    for video_path in video_paths:
        if capture_screenshots(video_path, output_dir, interval, image_format):
            success_count += 1

    print(f"Completed: {success_count}/{total_videos} videos processed successfully.")

    if success_count == total_videos:
        print(f"Screenshots saved to: {output_dir}")
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()

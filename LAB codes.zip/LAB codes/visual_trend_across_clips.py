from __future__ import annotations

import argparse
import os
import re
import textwrap
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp/lab_matplotlib_cache")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


DEFAULT_ROOT_DIR = Path("/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips")
DEFAULT_OUTPUT_DIR = DEFAULT_ROOT_DIR / "visual_trend_output"
PLOT_COLORS = {
    "lightness": "#FFC000",
    "lightness_range": "#FFC000",
    "mean_chroma": "blue",
    "chroma_p95": "red",
    "high_chroma_pixels": "green",
}


def natural_key(text: str) -> list[object]:
    return [int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", text)]


def clip_name_from_summary_path(path: Path) -> str:
    # Expected: .../clips/clipN/lab_analysis_output/<summary csv>
    if path.parent.name == "lab_analysis_output":
        return path.parent.parent.name
    return path.stem


def discover_summary_csvs(root_dir: Path) -> list[Path]:
    paths = list(root_dir.rglob("lab_collection_summary.csv"))
    paths.extend(root_dir.rglob("lab_summary.csv"))
    return sorted(paths, key=lambda p: natural_key(str(p)))


def normalize_clip_name(value: str) -> str:
    value = value.strip().lower()
    if value.startswith("clip"):
        return value
    if value.isdigit():
        return f"clip{value}"
    return value


def clip_number(clip_name: str) -> int | None:
    match = re.fullmatch(r"clip(\d+)", normalize_clip_name(clip_name))
    if match is None:
        return None
    return int(match.group(1))


def parse_clip_filter(clips: str | None) -> list[str] | None:
    if not clips:
        return None

    selected: list[str] = []

    def add_clip(clip_name: str) -> None:
        if clip_name not in selected:
            selected.append(clip_name)

    for part in clips.split(","):
        part = part.strip()
        if not part:
            continue

        if "-" in part:
            start_text, end_text = [item.strip() for item in part.split("-", 1)]
            start = clip_number(start_text)
            end = clip_number(end_text)
            if start is None or end is None:
                raise SystemExit(f"Invalid clip range: {part}")
            step = 1 if start <= end else -1
            for number in range(start, end + step, step):
                add_clip(f"clip{number}")
            continue

        normalized = normalize_clip_name(part)
        if clip_number(normalized) is None:
            raise SystemExit(f"Invalid clip name: {part}")
        add_clip(normalized)

    if not selected:
        raise SystemExit("No valid clips were provided.")
    return selected


def filter_summary_paths_by_clip(summary_paths: list[Path], clips: list[str] | None) -> list[Path]:
    if clips is None:
        return summary_paths

    clip_order = {clip: index for index, clip in enumerate(clips)}
    filtered_paths = [
        path for path in summary_paths
        if normalize_clip_name(clip_name_from_summary_path(path)) in clip_order
    ]
    found_clips = {normalize_clip_name(clip_name_from_summary_path(path)) for path in filtered_paths}
    missing_clips = [clip for clip in clips if clip not in found_clips]
    if missing_clips:
        print(f"Warning: no summary CSV found for: {', '.join(missing_clips)}")

    return sorted(
        filtered_paths,
        key=lambda path: (
            clip_order[normalize_clip_name(clip_name_from_summary_path(path))],
            natural_key(str(path)),
        ),
    )


def summary_row_from_path(path: Path) -> dict[str, object] | None:
    df = pd.read_csv(path)
    if df.empty:
        print(f"Skipping empty summary: {path}")
        return None

    if path.name == "lab_summary.csv":
        if "corpus_name" not in df.columns:
            return None
        average_rows = df[df["corpus_name"] == "overall average"]
        if average_rows.empty:
            return None

        row = average_rows.iloc[0]
        required_columns = ["L", "a", "b", "chroma", "contrast", "visual_feeling"]
        if not all(column in row.index for column in required_columns):
            return None

        image_rows = df[df["corpus_name"] != "overall average"]
        image_count = int(len(image_rows))
        summary = {
            "image_count": image_count,
            "average_L_across_images": float(row["L"]),
            "average_a_across_images": float(row["a"]),
            "average_b_across_images": float(row["b"]),
            "average_chroma_across_images": float(row["chroma"]),
            "average_contrast_across_images": float(row["contrast"]),
            "overall_visual_feeling": row["visual_feeling"],
            "_source_priority": 1,
        }
        optional_columns = {
            "chroma_std": "average_chroma_std_across_images",
            "chroma_p95": "average_chroma_p95_across_images",
            "high_chroma_pixel_pct": "average_high_chroma_pixel_pct_across_images",
        }
        for source_column, output_column in optional_columns.items():
            if source_column in row.index and pd.notna(row[source_column]):
                summary[output_column] = float(row[source_column])

        return summary

    row = df.iloc[0].to_dict()
    row["_source_priority"] = 0
    return row


def load_summaries(summary_paths: list[Path], clip_order: list[str] | None = None) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    requested_order = None if clip_order is None else {
        clip: index for index, clip in enumerate(clip_order)
    }

    for path in summary_paths:
        row = summary_row_from_path(path)
        if row is None:
            continue
        row["clip"] = clip_name_from_summary_path(path)
        row["summary_path"] = str(path)
        rows.append(row)

    if not rows:
        raise SystemExit("No readable LAB summary CSV files were found.")

    combined = pd.DataFrame(rows)
    if requested_order is None:
        combined["_clip_sort_order"] = (
            combined["clip"].astype(str).str.extract(r"(\d+)")[0].astype(float).fillna(np.inf)
        )
        combined = combined.sort_values(["_clip_sort_order", "clip", "_source_priority"])
        combined = combined.drop_duplicates("clip", keep="last")
        combined = combined.drop(columns=["_source_priority", "_clip_sort_order"])
        combined = combined.sort_values("clip", key=lambda col: col.map(natural_key)).reset_index(drop=True)
    else:
        combined["_clip_requested_order"] = (
            combined["clip"].map(lambda value: requested_order[normalize_clip_name(str(value))])
        )
        combined = combined.sort_values(["_clip_requested_order", "clip", "_source_priority"])
        combined = combined.drop_duplicates("clip", keep="last")
        combined = combined.drop(columns=["_source_priority", "_clip_requested_order"])
        combined = combined.sort_values(
            "clip",
            key=lambda col: col.map(lambda value: requested_order[normalize_clip_name(str(value))]),
        ).reset_index(drop=True)

    combined["clip_order"] = np.arange(1, len(combined) + 1)
    return combined


def add_average_row(df: pd.DataFrame) -> pd.DataFrame:
    """Append one whole-corpus weighted average row to the combined CSV."""
    df_with_average = df.copy()
    weights = df_with_average["image_count"].astype(float)
    total_images = int(weights.sum())

    average_row: dict[str, object] = {column: "" for column in df_with_average.columns}
    average_row["clip"] = "all clips"
    average_row["image_count"] = total_images
    average_row["clip_order"] = ""
    average_row["summary_path"] = ""
    average_row["overall_visual_feeling"] = ""

    weighted_average_columns = [
        "average_L_across_images",
        "average_a_across_images",
        "average_b_across_images",
        "average_chroma_across_images",
        "average_chroma_std_across_images",
        "average_chroma_p95_across_images",
        "average_high_chroma_pixel_pct_across_images",
        "average_contrast_across_images",
        "average_dark_pixel_pct_across_images",
    ]

    for column in weighted_average_columns:
        if column in df_with_average.columns:
            values = pd.to_numeric(df_with_average[column], errors="coerce")
            valid_values = values.notna()
            if valid_values.any():
                average_row[column] = float(
                    np.average(values[valid_values], weights=weights[valid_values])
                )

    return pd.concat([df_with_average, pd.DataFrame([average_row])], ignore_index=True)


def format_combined_csv(df: pd.DataFrame) -> pd.DataFrame:
    """Put the clip label first so each row is easy to read in the CSV."""
    df = df.copy()

    preferred_columns = [
        "clip",
        "image_count",
        "average_L_across_images",
        "average_a_across_images",
        "average_b_across_images",
        "average_chroma_across_images",
        "average_chroma_std_across_images",
        "average_chroma_p95_across_images",
        "average_high_chroma_pixel_pct_across_images",
        "average_contrast_across_images",
        "average_dark_pixel_pct_across_images",
        "overall_visual_feeling",
        "clip_order",
        "summary_path",
    ]
    remaining_columns = [column for column in df.columns if column not in preferred_columns]
    ordered_columns = [column for column in preferred_columns if column in df.columns] + remaining_columns

    return df[ordered_columns]


def save_metric_trends(df: pd.DataFrame, output_dir: Path) -> None:
    x = np.arange(len(df))
    labels = df["clip"].tolist()

    metrics = [
        ("average_L_across_images", "Average L*: Lightness", PLOT_COLORS["lightness"]),
        ("average_a_across_images", "Average a*: Green(-) to Red(+)", "green"),
        ("average_b_across_images", "Average b*: Blue(-) to Yellow(+)", "purple"),
        (
            "average_chroma_across_images",
            "Average Chroma: Color Intensity",
            PLOT_COLORS["mean_chroma"],
        ),
    ]

    plt.figure(figsize=(13, 7))
    for column, label, color in metrics:
        plt.plot(x, df[column], marker="o", linewidth=2, color=color, label=label)

    plt.axhline(0, color="black", linewidth=0.8, alpha=0.25)
    plt.xticks(x, labels, rotation=45, ha="right")
    plt.ylabel("LAB / chroma value")
    plt.title("Visual Development Trend Across Clips")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "lab_trend_across_clips.png", dpi=300)
    plt.close()

    fig, axes = plt.subplots(2, 2, figsize=(13, 8), sharex=True)
    axes = axes.flatten()

    for ax, (column, label, color) in zip(axes, metrics):
        ax.plot(x, df[column], marker="o", linewidth=2, color=color)
        ax.set_title(label)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=45, ha="right")
        ax.grid(True, alpha=0.25)

    fig.suptitle("LAB Components by Clip", fontsize=14)
    fig.tight_layout()
    fig.savefig(output_dir / "lab_components_by_clip.png", dpi=300)
    plt.close(fig)


def save_affective_trends(df: pd.DataFrame, output_dir: Path) -> None:
    if "average_contrast_across_images" not in df.columns:
        return

    x = np.arange(len(df))
    labels = df["clip"].tolist()

    plt.figure(figsize=(13, 6))
    plt.plot(
        x,
        df["average_contrast_across_images"],
        marker="o",
        linewidth=2,
        color=PLOT_COLORS["lightness_range"],
        label="Average contrast: L* p95 - p05",
    )
    if "average_chroma_p95_across_images" in df.columns:
        plt.plot(
            x,
            df["average_chroma_p95_across_images"],
            marker="o",
            linewidth=2,
            color=PLOT_COLORS["chroma_p95"],
            label="Average chroma p95: localized vividness",
        )
    if "average_high_chroma_pixel_pct_across_images" in df.columns:
        plt.plot(
            x,
            df["average_high_chroma_pixel_pct_across_images"],
            marker="o",
            linewidth=2,
            color=PLOT_COLORS["high_chroma_pixels"],
            label="Average high-chroma pixels (%)",
        )
    if "average_dark_pixel_pct_across_images" in df.columns:
        plt.plot(
            x,
            df["average_dark_pixel_pct_across_images"],
            marker="o",
            linewidth=2,
            label="Average very-dark pixels: L* < 20 (%)",
        )
    plt.xticks(x, labels, rotation=45, ha="right")
    plt.ylabel("Metric value")
    plt.title("Contrast and Darkness Trend Across Clips")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "contrast_darkness_trend.png", dpi=300)
    plt.close()


def save_visual_feeling_table(df: pd.DataFrame, output_dir: Path) -> None:
    table_columns = [
        "clip",
        "image_count",
        "average_L_across_images",
        "average_a_across_images",
        "average_b_across_images",
        "average_chroma_across_images",
        "average_chroma_p95_across_images",
        "average_high_chroma_pixel_pct_across_images",
        "overall_visual_feeling",
    ]
    table_columns = [column for column in table_columns if column in df.columns]
    table_df = df[table_columns].copy()

    for column in [
        "average_L_across_images",
        "average_a_across_images",
        "average_b_across_images",
        "average_chroma_across_images",
        "average_chroma_p95_across_images",
        "average_high_chroma_pixel_pct_across_images",
    ]:
        if column in table_df.columns:
            table_df[column] = table_df[column].map(lambda value: f"{value:.2f}")

    wrapped_feelings = table_df["overall_visual_feeling"].map(
        lambda value: "\n".join(textwrap.wrap(str(value), width=48))
    )
    max_visual_lines = max(
        (wrapped_value.count("\n") + 1 for wrapped_value in wrapped_feelings),
        default=1,
    )
    table_df["overall_visual_feeling"] = wrapped_feelings

    fig_height = max(4.5, (0.42 * max_visual_lines * len(table_df)) + 1.8)
    fig, ax = plt.subplots(figsize=(16, fig_height))
    ax.axis("off")

    column_labels = {
        "clip": "Clip",
        "image_count": "Images",
        "average_L_across_images": "L*",
        "average_a_across_images": "a*",
        "average_b_across_images": "b*",
        "average_chroma_across_images": "Chroma",
        "average_chroma_p95_across_images": "Chroma p95",
        "average_high_chroma_pixel_pct_across_images": "High chroma %",
        "overall_visual_feeling": "Visual feeling",
    }
    table_widths = {
        "clip": 0.08,
        "image_count": 0.08,
        "average_L_across_images": 0.08,
        "average_a_across_images": 0.08,
        "average_b_across_images": 0.08,
        "average_chroma_across_images": 0.10,
        "average_chroma_p95_across_images": 0.10,
        "average_high_chroma_pixel_pct_across_images": 0.12,
        "overall_visual_feeling": 0.28,
    }

    table = ax.table(
        cellText=table_df.values,
        colLabels=[column_labels[column] for column in table_df.columns],
        cellLoc="left",
        colLoc="left",
        colWidths=[table_widths[column] for column in table_df.columns],
        loc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1, max(1.8, 0.82 * max_visual_lines))

    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_text_props(weight="bold")
            cell.set_facecolor("#eeeeee")
        cell.get_text().set_va("center")

    fig.tight_layout()
    fig.savefig(output_dir / "visual_feelings_by_clip.png", dpi=300)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Combine lab_collection_summary.csv files and visualize visual trends across clips."
    )
    parser.add_argument(
        "summary_csvs",
        nargs="*",
        type=Path,
        help="Optional explicit lab_collection_summary.csv paths. If omitted, the script auto-discovers them.",
    )
    parser.add_argument(
        "--root-dir",
        type=Path,
        default=DEFAULT_ROOT_DIR,
        help=f"Folder to search recursively. Default: {DEFAULT_ROOT_DIR}",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Output folder. Default: {DEFAULT_OUTPUT_DIR}",
    )
    parser.add_argument(
        "--clips",
        type=str,
        default=None,
        help=(
            "Optional clips to analyze, using comma-separated names/numbers and ranges. "
            "Examples: clip1,clip3 or clip1-clip7 or 1-7."
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(output_dir / ".matplotlib"))

    summary_paths = [path.expanduser() for path in args.summary_csvs]
    if not summary_paths:
        summary_paths = discover_summary_csvs(args.root_dir.expanduser())

    selected_clips = parse_clip_filter(args.clips)
    summary_paths = filter_summary_paths_by_clip(summary_paths, selected_clips)

    if not summary_paths:
        clip_detail = f" matching --clips {args.clips!r}" if args.clips else ""
        raise SystemExit(f"No LAB summary CSV files found under: {args.root_dir}{clip_detail}")

    combined = load_summaries(summary_paths, selected_clips)
    combined_with_average = add_average_row(combined)
    combined_csv_path = output_dir / "combined_lab_collection_summary.csv"
    format_combined_csv(combined_with_average).to_csv(combined_csv_path, index=False)

    save_metric_trends(combined, output_dir)
    save_affective_trends(combined, output_dir)
    save_visual_feeling_table(combined, output_dir)

    print("Visual trend analysis finished.")
    print(f"Combined {len(combined)} clip summary file(s).")
    print(f"Saved combined CSV to: {combined_csv_path}")
    print(f"Saved plot to: {output_dir / 'lab_trend_across_clips.png'}")
    print(f"Saved plot to: {output_dir / 'lab_components_by_clip.png'}")
    print(f"Saved plot to: {output_dir / 'contrast_darkness_trend.png'}")
    print(f"Saved table image to: {output_dir / 'visual_feelings_by_clip.png'}")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp/lab_matplotlib_cache")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


DEFAULT_CSV_PATHS = [
    Path(
        "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/"
        "visual_trend_setup/combined_lab_collection_summary_setup.csv"
    ),
    Path(
        "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/"
        "visual_trend_act1/combined_lab_collection_summary_act1.csv"
    ),
    Path(
        "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/"
        "visual_trend_act2/combined_lab_collection_summary_act2.csv"
    ),
    Path(
        "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/"
        "visual_trend_act3/combined_lab_collection_summary_act3.csv"
    ),
]
DEFAULT_OUTPUT_DIR = Path(
    "/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/4_act/lab_set_comparison"
)

PLOT_COLORS = {
    "lightness": "#FFC000",
    "mean_chroma": "blue",
    "chroma_std": "purple",
    "chroma_p95": "red",
    "high_chroma_pixels": "green",
    "contrast": "#FFC000",
}

PREFERRED_METRICS = [
    "average_L_across_images",
    "average_chroma_across_images",
    "average_chroma_std_across_images",
    "average_chroma_p95_across_images",
    "average_high_chroma_pixel_pct_across_images",
    "average_contrast_across_images",
]


def label_from_path(path: Path) -> str:
    parent_name = path.parent.name
    if parent_name:
        return parent_name
    return path.stem


def parse_labels(label_text: str | None, csv_paths: list[Path]) -> list[str]:
    if label_text is None:
        return [label_from_path(path) for path in csv_paths]

    labels = [label.strip() for label in label_text.split(",") if label.strip()]
    if len(labels) != len(csv_paths):
        raise SystemExit(
            f"--labels must provide exactly {len(csv_paths)} label(s), separated by commas."
        )
    return labels


def numeric_metric_columns(df: pd.DataFrame) -> list[str]:
    return [
        column
        for column in df.columns
        if column.startswith("average_") and column.endswith("_across_images")
    ]


def summary_row_from_csv(path: Path, label: str) -> dict[str, object]:
    df = pd.read_csv(path)
    if df.empty:
        raise SystemExit(f"CSV is empty: {path}")
    if "clip" not in df.columns:
        raise SystemExit(f"CSV lacks required 'clip' column: {path}")

    all_clips = df[df["clip"].astype(str).str.lower() == "all clips"]
    if not all_clips.empty:
        row = all_clips.iloc[-1]
    else:
        if "image_count" not in df.columns:
            raise SystemExit(
                f"CSV has no 'all clips' row and lacks image_count for weighted averages: {path}"
            )
        weights = pd.to_numeric(df["image_count"], errors="coerce")
        valid_weights = weights.notna() & (weights > 0)
        if not valid_weights.any():
            raise SystemExit(f"CSV has no usable image_count values: {path}")

        row_values: dict[str, object] = {}
        for column in numeric_metric_columns(df):
            values = pd.to_numeric(df[column], errors="coerce")
            valid = valid_weights & values.notna()
            if valid.any():
                row_values[column] = float(np.average(values[valid], weights=weights[valid]))
        row_values["image_count"] = int(weights[valid_weights].sum())
        row = pd.Series(row_values)

    summary: dict[str, object] = {
        "set": label,
        "image_count": int(pd.to_numeric(row.get("image_count", 0), errors="coerce")),
        "source_csv": str(path),
    }
    for column in numeric_metric_columns(pd.DataFrame([row])):
        value = pd.to_numeric(pd.Series([row[column]]), errors="coerce").iloc[0]
        if pd.notna(value):
            summary[column] = float(value)

    return summary


def add_all_sets_average(df: pd.DataFrame) -> pd.DataFrame:
    weights = pd.to_numeric(df["image_count"], errors="coerce")
    valid_weights = weights.notna() & (weights > 0)
    total_images = int(weights[valid_weights].sum())

    average_row: dict[str, object] = {column: "" for column in df.columns}
    average_row["set"] = "all sets"
    average_row["image_count"] = total_images
    average_row["source_csv"] = ""

    for column in numeric_metric_columns(df):
        values = pd.to_numeric(df[column], errors="coerce")
        valid = valid_weights & values.notna()
        if valid.any():
            average_row[column] = float(np.average(values[valid], weights=weights[valid]))

    return pd.concat([df, pd.DataFrame([average_row])], ignore_index=True)


def ordered_columns(df: pd.DataFrame) -> list[str]:
    preferred = [
        "set",
        "image_count",
        "average_L_across_images",
        "average_a_across_images",
        "average_b_across_images",
        "average_chroma_across_images",
        "average_chroma_std_across_images",
        "average_chroma_p95_across_images",
        "average_high_chroma_pixel_pct_across_images",
        "average_contrast_across_images",
        "source_csv",
    ]
    return [column for column in preferred if column in df.columns] + [
        column for column in df.columns if column not in preferred
    ]


def save_trend_plot(df: pd.DataFrame, output_dir: Path) -> None:
    plot_df = df[df["set"] != "all sets"].copy()
    x = np.arange(len(plot_df))
    labels = plot_df["set"].astype(str).tolist()

    metrics = [
        ("average_L_across_images", "Average L*: Lightness", PLOT_COLORS["lightness"], "-"),
        ("average_chroma_across_images", "Mean chroma", PLOT_COLORS["mean_chroma"], "-"),
        ("average_chroma_std_across_images", "Chroma std", PLOT_COLORS["chroma_std"], "-"),
        ("average_chroma_p95_across_images", "Chroma p95", PLOT_COLORS["chroma_p95"], "-"),
        (
            "average_high_chroma_pixel_pct_across_images",
            "High-chroma pixels (%)",
            PLOT_COLORS["high_chroma_pixels"],
            "-",
        ),
        (
            "average_contrast_across_images",
            "Contrast: L* p95 - p05",
            PLOT_COLORS["contrast"],
            "--",
        ),
    ]

    plt.figure(figsize=(13, 7))
    for column, label, color, linestyle in metrics:
        if column not in plot_df.columns:
            continue
        values = pd.to_numeric(plot_df[column], errors="coerce")
        if values.notna().any():
            plt.plot(
                x,
                values,
                marker="o",
                linewidth=2.4,
                color=color,
                linestyle=linestyle,
                label=label,
            )

    plt.xticks(x, labels, rotation=30, ha="right")
    plt.ylabel("Metric value")
    plt.title("LAB Summary Comparison Across Sets")
    plt.legend()
    plt.grid(True, alpha=0.2)
    plt.tight_layout()
    plt.savefig(output_dir / "lab_set_average_trends.png", dpi=300)
    plt.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Compare combined LAB summary CSVs, such as act-level visual trend outputs."
        )
    )
    parser.add_argument(
        "csv_paths",
        nargs="*",
        type=Path,
        help=(
            "Combined LAB summary CSVs to compare, in the exact order to plot. "
            "If omitted, act1/act2/act3 defaults are used."
        ),
    )
    parser.add_argument(
        "--labels",
        type=str,
        default=None,
        help="Optional comma-separated display labels matching the CSV path order.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Output folder. Default: {DEFAULT_OUTPUT_DIR}",
    )
    parser.add_argument(
        "--output-name",
        type=str,
        default="lab_set_average_summary.csv",
        help="Output CSV filename. Default: lab_set_average_summary.csv",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    csv_paths = [path.expanduser() for path in args.csv_paths] or DEFAULT_CSV_PATHS
    labels = parse_labels(args.labels, csv_paths)

    output_dir = args.output_dir.expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(output_dir / ".matplotlib"))

    missing_paths = [path for path in csv_paths if not path.exists()]
    if missing_paths:
        missing_text = "\n".join(str(path) for path in missing_paths)
        raise SystemExit(f"CSV path(s) not found:\n{missing_text}")

    rows = [
        summary_row_from_csv(path, label)
        for path, label in zip(csv_paths, labels, strict=True)
    ]
    summary_df = pd.DataFrame(rows)
    summary_df = summary_df[ordered_columns(summary_df)]
    summary_with_average = add_all_sets_average(summary_df)

    csv_path = output_dir / args.output_name
    summary_with_average.to_csv(csv_path, index=False)
    save_trend_plot(summary_with_average, output_dir)

    print("LAB set comparison finished.")
    print(f"Compared {len(summary_df)} CSV file(s).")
    print(f"Saved comparison CSV to: {csv_path}")
    print(f"Saved trend plot to: {output_dir / 'lab_set_average_trends.png'}")


if __name__ == "__main__":
    main()

import sys
from pathlib import Path
from scenedetect import SceneManager, open_video
from scenedetect.detectors import ContentDetector

# ─── CONFIGURATION ─────────────────────────────────────────────────────────────
TARGET_DIR = Path('/Users/jemincejem/Downloads/LAB/call_me_by_your_name/clips/clip24')
TARGET_VIDEO = TARGET_DIR / 'clip24.mp4'
THRESHOLD  = 8.0     # lower = more sensitive; useful for short/subtle clips
DOWNSCALE  = 1       # keep full resolution for short clips

# ─── FUNCTION DEFINITIONS ──────────────────────────────────────────────────────
def video_duration_seconds(video_path):
    """
    Returns the total video duration in seconds.
    Used when no cuts are detected, because a no-cut clip is still one shot.
    """
    video = open_video(video_path)
    return video.duration.get_seconds()


def average_shot_length(video_path, threshold=THRESHOLD, downscale=DOWNSCALE):
    """
    Detects scenes in `video_path` and returns:
      (average_shot_length_s, total_duration_s, shot_count)
    """
    video = open_video(video_path)
    sm = SceneManager()
    sm.add_detector(ContentDetector(threshold=threshold))
    sm.auto_downscale = False
    sm.downscale = downscale

    sm.detect_scenes(video=video)
    scenes = sm.get_scene_list()

    durations = [(end.get_seconds() - start.get_seconds())
                 for start, end in scenes]

    if not durations:
        total = video_duration_seconds(video_path)
        return total, total, 1

    total = sum(durations)
    count = len(durations)
    avg   = (total / count) if count > 0 else 0.0
    return avg, total, count

def main():
    # 1) Verify directory exists
    if not TARGET_DIR.is_dir():
        print(f"Error: directory not found: {TARGET_DIR}", file=sys.stderr)
        sys.exit(1)

    # 2) Analyze only the designated file
    if not TARGET_VIDEO.is_file():
        print(f"Error: target video not found: {TARGET_VIDEO}", file=sys.stderr)
        sys.exit(1)

    # 3) Process only clip24.mp4
    try:
        avg_len, total_dur, shot_count = average_shot_length(str(TARGET_VIDEO))
    except Exception as e:
        print(f"Error processing {str(TARGET_VIDEO)!r}: {e}", file=sys.stderr)
        sys.exit(1)

    # 4) Print single-file result
    if shot_count > 0:
        print(f"Video analyzed: {TARGET_VIDEO}")
        print(f"Average shot length: {avg_len:.2f} s")
        print(f"Total analyzed duration: {total_dur:.2f} s")
        print(f"Detected shot count: {shot_count}")
    else:
        print(f"No shots detected in: {TARGET_VIDEO}")

if __name__ == '__main__':
    main()
